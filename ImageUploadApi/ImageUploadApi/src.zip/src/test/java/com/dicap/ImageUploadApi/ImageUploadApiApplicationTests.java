package com.dicap.ImageUploadApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageUploadApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
